﻿Nuker Installation Guide
Made by @mdibladi

1. Install Python 3.10.5 from https://www.python.org/ftp/python/3.10.5/python-3.10.5-amd64.exe
   - Make sure to check "Add Python to PATH" during installation

2. Install required packages by running these commands in Command Prompt:
   pip install discord.py
   pip install PyQt5
   pip install requests
   pip install pyarmor
   pip install colorama
   or copy this
   pip isntall discord.py pyqt5 requests pyarmor colorama

3. Run setup.bat

Join our Discord server for support: discord.gg/mdi

Note: The script is protected to prevent unauthorized modifications.