# Pyarmor 9.1.2 (trial), 000000, 2025-05-08T22:43:30.658743
from .pyarmor_runtime import __pyarmor__
